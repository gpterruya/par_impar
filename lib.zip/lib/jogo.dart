class Jogo {
  String usernameLocal;
  String usernameRemoto;
  double valor;
  int parImpar;
  double numero;

  Jogo({
    required this.usernameLocal,
    required this.usernameRemoto,
    required this.valor,
    required this.parImpar,
    required this.numero,
  });
}
